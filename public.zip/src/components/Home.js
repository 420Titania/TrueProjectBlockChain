    import React from 'react'
    import Navbar from "./Navbar";
    import Tablist from "./Tablist";

    function Home() {
        return ( <div className="home-container">
            <Navbar/>
                <Tablist/>
        </div>
    );
    }


    export default Home;
